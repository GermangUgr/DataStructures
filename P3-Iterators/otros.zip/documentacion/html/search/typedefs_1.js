var searchData=
[
  ['size_5ftype',['size_type',['../classconjunto.html#a0cc9902da62790ec2a6d59f4559c2df5',1,'conjunto']]]
];
