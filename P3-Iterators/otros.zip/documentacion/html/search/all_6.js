var searchData=
[
  ['getarrest',['getArrest',['../classcrimen.html#a6cab67bfdad566ce444236fc7c8df312',1,'crimen']]],
  ['getcasenumber',['getCaseNumber',['../classcrimen.html#ab3c025eb20cdcea9192ee190fa2af015',1,'crimen']]],
  ['getdate',['getDate',['../classcrimen.html#a8a6712e536211034819441ab87e1c215',1,'crimen']]],
  ['getdescription',['getDescription',['../classcrimen.html#a61789d65209d167149df197272d8feba',1,'crimen']]],
  ['getdomestic',['getDomestic',['../classcrimen.html#a1849e7a82111773a6919318b9cf1d05d',1,'crimen']]],
  ['getid',['getID',['../classcrimen.html#a855eab30a304a6498828cb5d85a4e0e3',1,'crimen']]],
  ['getiucr',['getIUCR',['../classcrimen.html#a8738020069c3a3b3500d044f9580f93a',1,'crimen']]],
  ['getlatitude',['getLatitude',['../classcrimen.html#adfd62cd48c7d1d0259c007d3f6c39d58',1,'crimen']]],
  ['getlocationdescription',['getLocationDescription',['../classcrimen.html#a9de655b3eea3592f6e5d017e83fd6060',1,'crimen']]],
  ['getlongitude',['getLongitude',['../classcrimen.html#a0c24726cd34dc975b3fc7c664287a15c',1,'crimen']]],
  ['getprimarytype',['getPrimaryType',['../classcrimen.html#ae47e93acec39b388cde221a679bccf9c',1,'crimen']]]
];
