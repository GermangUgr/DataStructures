var searchData=
[
  ['date',['Date',['../classcrimen.html#a43fdb792dbc2e2927592fad7fb8b224c',1,'crimen']]],
  ['description',['Description',['../classcrimen.html#aa51b9ddc58248aadefdb8fad7d4cd69b',1,'crimen']]],
  ['documentacion_2edox',['documentacion.dox',['../documentacion_8dox.html',1,'']]],
  ['domestic',['Domestic',['../classcrimen.html#a53f0bfea0c8ebb03dda9bf7332057477',1,'crimen']]],
  ['documentación_20práctica',['Documentación Práctica',['../index.html',1,'']]]
];
