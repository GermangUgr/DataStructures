var searchData=
[
  ['insert',['insert',['../classconjunto.html#a61c22092268cc91439b93a2fd96e4173',1,'conjunto']]],
  ['iterator',['iterator',['../classconjunto_1_1iterator.html#a3f22236830d397ec750b795e4358492d',1,'conjunto::iterator::iterator()'],['../classconjunto_1_1iterator.html#ae6ffce98c8835de978c7b8f0a769a1fe',1,'conjunto::iterator::iterator(const iterator &amp;it)']]]
];
